<?php

define('EDGE_CORE_VERSION', '1.0');
define('EDGE_CORE_ABS_PATH', dirname(__FILE__));
define('EDGE_CORE_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('EDGE_CORE_CPT_PATH', EDGE_CORE_ABS_PATH.'/post-types');